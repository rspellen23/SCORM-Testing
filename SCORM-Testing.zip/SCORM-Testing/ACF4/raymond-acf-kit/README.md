# Raymond's ACF Two-Layer Kit (Claude Code, macOS/Linux)

This sets up Claude Code to work the way it does on James's machine: the
**two-layer ACF interactive system** (Layer 1 = how-we-work, Layer 2 =
Luminescent-specific rules), enforced by `SessionStart` + `PreToolUse`
hooks and backed by a persistent file-based memory tree.

This kit is a refreshed, **macOS/Linux** port. It is current as of the
date it was generated — it includes the conscience-gate pre-execute
checklist and the Layer-0 orienting-question discipline (both newer than
the older Windows `acf-toolkit-v3`).

> **Layer 0 (your "ontology layer + DB") is NOT in here.** That's the
> pgvector "second brain," which you already have set up. This kit is only
> the Claude *interaction* layers (1 + 2) that sit on top of it.

---

## What it installs

**Layer 1 — user-global** (to `~/` and `~/.claude/`):

| File | Purpose |
|---|---|
| `~/CLAUDE.md` | Universal engagement rules (ACF loop + Standing Rules). Auto-loaded every session. |
| `~/.claude/hooks/layer1-orientation.py` | `SessionStart` hook — injects orientation + the mandatory first-response line. |
| `~/.claude/hooks/pre-execute-checklist.py` | `PreToolUse` (Edit/Write/Bash) — conscience gate + 6-step checklist into context before every state-changing action. |
| `~/.claude/hooks/validate-memory-write.py` | `PreToolUse` (Edit/Write) — blocks memory writes to unrecognized project keys. |
| `~/.claude/memory/*.md` | ACF doctrine (collaboration loop, failed-patterns, working-style template) + index. |
| `~/.claude/settings.json` | Hook registrations — **merged** into your existing file, never clobbered. |

**Layer 2 — Luminescent project** (dropped into your *clone* of the repo):

| File | Why the kit ships it |
|---|---|
| `<clone>/.claude/hooks/session-orientation.py` | The project `SessionStart` hook. **Not in git** — clone won't deliver it. |
| `<clone>/.claude/hooks/validate-memory-write.py` | Project-level memory guard. **Not in git.** |
| `<clone>/.claude/hooks/check-pregenerate-fast.py` | Pre-Generate paid-API guard. **Not in git.** Path made env-configurable. |
| `<clone>/.claude/settings.json` | Registers the project hooks. **Not in git.** |

> **`CLAUDE.md` and `AGENTS.md` come from `git clone`** (they *are* tracked).
> So is `scan-secrets.py`. The four files above are the ones that don't
> travel with the repo — that's why this kit bundles them.

**Project memory seed** (to `~/.claude/projects/<key>/memory/`): fresh
`MEMORY.md` / `passdown.md` / `failed-approaches.md` skeletons. This is a
**clean tree** — it does *not* contain James's accumulated Luminescent
history. You grow your own.

---

## Prerequisites

1. **Claude Code** installed and working.
2. **Python 3.8+** on `PATH` (the hooks are Python; the installer uses it too).
3. **Your Luminescent clone** already on disk (Layer 2 drops into it, and
   `CLAUDE.md`/`AGENTS.md` come from the clone).
4. Layer 0 (the pgvector "second brain") already set up — you have this.

---

## Install

```bash
chmod +x install.sh
./install.sh --repo "$HOME/code/Luminescent" --name Raymond
```

Common variants:

```bash
# See exactly what it would touch, write nothing:
./install.sh --repo "$HOME/code/Luminescent" --dry-run

# You already know your project key (skip the derive-and-verify dance):
./install.sh --repo "$HOME/code/Luminescent" --name Raymond --key "-Users-raymond-code-Luminescent"

# Layer 1 only for now (set up Layer 2 later):
./install.sh --layer1-only --name Raymond
```

The installer:
- **Is idempotent** — re-running won't duplicate hook registrations and
  won't overwrite existing project memory.
- **Backs up** any file it would overwrite (`.acf-backup-<timestamp>`),
  unless you pass `--force`.
- **Merges** hook blocks into existing `settings.json` files — it never
  replaces them.
- Autodetects `python3` / `python`; override with `--python`.

Run `./install.sh --help` for all flags.

---

## ⚠️ Project keys are per-machine — verify yours

Claude Code derives the project memory key from the **absolute path** of the
repo. James's key is `c--Edusworks-Luminescent` because his clone is at
`C:\Edusworks\Luminescent`. **Your key will be different** because your
clone is at a different path.

The installer derives a best-effort key from `--repo` and warns you to
verify it. The memory guard is **existence-based** (it allows any project
key whose memory dir exists, blocks unknown ones), so a wrong guess fails
*gracefully*: the first blocked write names the correct key.

To confirm after install:

```bash
# Open one Claude session inside your clone, then:
ls ~/.claude/projects/
```

If the directory there differs from the key the installer used, either
re-run with `--key <actual>` or just move the seeded memory:

```bash
mv ~/.claude/projects/<derived-key> ~/.claude/projects/<actual-key>
```

---

## Verify the install

1. **Layer 1 fires:** open Claude Code anywhere; the first reply must begin
   `"Layer 1 orientation loaded. Default project: Luminescent (unless told otherwise)."`
2. **Layer 2 fires:** open Claude Code *inside your Luminescent clone*; the
   first reply should begin `"Layer 1 + Layer 2 (Luminescent) orientation loaded."`
3. **Memory guard works:** ask Claude to `Write` to
   `~/.claude/projects/c--bogus-key/memory/test.md`. It must be **BLOCKED**.
4. **Pre-execute checklist fires:** on any Edit/Write/Bash, the conscience-gate
   block appears in context.

---

## Two notes specific to your setup

**The dual-repo thing.** Luminescent has two repos: the Archive
(`Luminescent`) and Operations (`Luminescent.World`). This kit's Layer 2 is
keyed to whatever clone you point `--repo` at. The pre-Generate guard scans
the *Operations* platform tree — set `LUMINESCENT_PLATFORM_ROOT` to your
Operations clone's `platform/src/luminescent_platform` so it actually runs
(otherwise it prints "skipping" and exits cleanly):

```bash
echo 'export LUMINESCENT_PLATFORM_ROOT="$HOME/code/Luminescent.World/platform/src/luminescent_platform"' >> ~/.zshrc
```

**Local stack rule.** Layer 1 carries the "no paid APIs without per-run
consent" rule (default LLM = Qwen/Ollama). If your local stack differs from
James's, edit `~/CLAUDE.md` Standing Rule 1 and the same rule in
`~/.claude/hooks/layer1-orientation.py`.

---

## What's deliberately NOT included

- **James's accumulated memory** (450 project files + his Layer-1 memory).
  By design — you start fresh. The ACF *method* docs are included (scrubbed);
  the *history* is not.
- **Layer 0** (pgvector second brain) — you already have it.
- **Skills / MCP servers / slash commands** — out of scope; add separately.
