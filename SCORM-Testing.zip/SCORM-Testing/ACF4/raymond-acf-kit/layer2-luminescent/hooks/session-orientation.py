#!/usr/bin/env python3
"""Layer 2 ({{PROJECT_NAME}}-specific) SessionStart hook — short orientation.

Fires only when a session is launched inside the {{PROJECT_NAME}} repo.
Layer 1 (the user-global hook at ~/.claude/hooks/layer1-orientation.py)
fires alongside this one and handles cross-project collaboration rules.
This hook handles {{PROJECT_NAME}}-specific orientation only.

Target: under 1500 bytes of stdout so nothing gets truncated to preview.

The full {{PROJECT_NAME}} memory system lives at:
  ~/.claude/projects/{{PROJECT_KEY}}/memory/
This hook does NOT dump those files — it points at them. The agent has
Read-tool access and can load any of them directly if it needs detail.

Parameterized by the ACF kit installer:
  {{PROJECT_NAME}} {{PROJECT_KEY}} {{PROJECT_PATH}}
"""
from __future__ import annotations

import sys

# Force UTF-8 stdout so non-ASCII characters don't crash the hook.
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        import io

        sys.stdout = io.TextIOWrapper(
            sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True
        )

MESSAGE = """\
LAYER 2 ORIENTATION ({{PROJECT_NAME}} project, auto-injected by
{{PROJECT_PATH}}/.claude/hooks/session-orientation.py)

This hook fires IN ADDITION to the Layer 1 hook. Both apply.

*** ACKNOWLEDGE BOTH LAYERS ***
Your first-response acknowledgment line should be:
  "Layer 1 + Layer 2 ({{PROJECT_NAME}}) orientation loaded."
Then address the user's message normally.

{{PROJECT_NAME}}-SPECIFIC RULES (full text in project files below):

1. NO MIXINS in writers_room/. The pattern is dead. SlotCoordinator
   (lumi/spindle/slot_coordinator.py) is the canonical replacement.
   Do NOT propose mixin-based solutions. Do NOT "improve" existing
   mixin code — treat it as scheduled for retirement, not canonical.

2. TEMPLATES ARE PAGES. No section-per-page assembly. A two-column
   page has sidebar content AND main content as different sections in
   the same page template. This is DTP thinking, not web thinking.

3. EDITOR IS THE PRODUCT. Pipeline feeds the Editor — it does not
   auto-generate finished books. Optimize for "complete editable
   entities," not "perfect PDF on first run."

4. THE SEAM IS COMPILE, not generation. Precompile edits entities,
   postcompile edits the publication. Generation happens in both zones.

5. SRD content is reference-only. Never user-pickable, never linked-by-
   reference from user content, never embedded in shipping artifacts.

MEMORY WRITES for {{PROJECT_NAME}} go to:
  ~/.claude/projects/{{PROJECT_KEY}}/memory/
Layer 1's validate-memory-write hook enforces this.

READ THESE if you need detail (Read tool):
  {{PROJECT_PATH}}/CLAUDE.md          (project engagement rules)
  {{PROJECT_PATH}}/AGENTS.md          (project patterns)
  ~/.claude/projects/{{PROJECT_KEY}}/memory/MEMORY.md
  ~/.claude/projects/{{PROJECT_KEY}}/memory/passdown.md
  ~/.claude/projects/{{PROJECT_KEY}}/memory/failed-approaches.md
"""


def main() -> int:
    sys.stdout.write(MESSAGE)
    return 0


if __name__ == "__main__":
    sys.exit(main())
