#!/usr/bin/env python3
"""Layer 1 SessionStart hook — short orientation injection.

Fires on EVERY Claude Code session start, regardless of CWD. It does NOT
dump file contents (that bloats the preview and gets truncated). It prints
a short, high-priority instruction block the agent cannot miss, and points
at the files that hold the detail.

Target: under 1500 bytes of stdout so nothing gets truncated to preview.

Installed/parameterized by the ACF kit installer:
  {{USER_NAME}}    -> the user's name
  {{PROJECT_NAME}} -> default project display name (e.g. "Luminescent")
  {{PROJECT_KEY}}  -> default project memory key (e.g. "c--Edusworks-Luminescent")
  {{PROJECT_PATH}} -> default project repo path on this machine
"""
from __future__ import annotations

import sys

# Force UTF-8 stdout so box/non-ASCII characters don't crash the hook.
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        import io

        sys.stdout = io.TextIOWrapper(
            sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True
        )

MESSAGE = """\
LAYER 1 ORIENTATION (auto-injected by ~/.claude/hooks/layer1-orientation.py)

*** FIRST-RESPONSE REQUIREMENT ***
Your very first response in this session MUST begin with this exact line:
  "Layer 1 orientation loaded. Default project: {{PROJECT_NAME}} (unless told otherwise)."
Then answer the user's question normally. If you skip the acknowledgment,
{{USER_NAME}} cannot tell the protection system is working. Do NOT skip it
even if the user's first message is trivial.

RULES (full text in ~/CLAUDE.md, which is auto-loaded by Claude Code):

1. LOCAL STACK ONLY. Default LLM is Qwen/Ollama; default art is Diffusers.
   NEVER call paid APIs (Anthropic, OpenAI, BFL, Leonardo, Recraft) without
   {{USER_NAME}} saying "turn on APIs for this run." Never hardcode provider=
   "anthropic" or adapter.anthropic_model. Treat existing hardcoded
   providers as bugs to fix.

2. CHECK THE RECORD before agreeing with claims. When the user says "X
   keeps happening" or "we decided this," run git log / grep memory /
   check the failed-approaches log BEFORE building on the hypothesis.

3. MEMORY WRITES go to the TARGET project's memory dir, not the session's.
   {{PROJECT_NAME}} = ~/.claude/projects/{{PROJECT_KEY}}/memory/
   The PreToolUse hook blocks unrecognized project keys. Don't work around it.

4. USE EXISTING memory files. Don't bootstrap parallel systems.

5. ONE FILE PER CONCEPT. Append to existing files instead of creating
   slightly-different-named new ones.

DEFAULT PROJECT: {{PROJECT_NAME}}. Repo at {{PROJECT_PATH}}. If you're
not sure what project the user wants, ASK.

READ THESE if you need detail (all on disk, use Read tool):
  ~/CLAUDE.md
  ~/.claude/memory/MEMORY.md
  ~/.claude/memory/acf-collaboration-loop.md
  ~/.claude/memory/acf-failed-collaboration-patterns.md
"""


def main() -> int:
    sys.stdout.write(MESSAGE)
    return 0


if __name__ == "__main__":
    sys.exit(main())
