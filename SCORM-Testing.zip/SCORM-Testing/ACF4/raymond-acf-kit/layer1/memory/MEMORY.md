# Layer 1 — User-Level Memory

> Universal collaboration framework. Loads for EVERY session, regardless of project.
> Project-specific memory lives at Layer 2 — see the project's own MEMORY.md at
> `~/.claude/projects/<project-key>/memory/MEMORY.md`.

## Standing Orders

These are durable rules. Do not change unless I explicitly request.

1. **Check the record before agreeing.** When I say "X keeps happening" — run git log, grep memory, check failed-approaches BEFORE building on the hypothesis.
2. **Memory writes go to the target project.** Project memory lives at `~/.claude/projects/<project-key>/memory/`. The hook blocks wrong paths.
3. **Use existing memory systems.** Look before creating. Append before proliferating.
4. **One file per concept.** If it fits in an existing file, put it there.
5. **Active orientation at session start.** Read the project passdown. State what it says. Be ready to continue without re-explanation.
6. **Interview before significant work.** ANCHOR > INTERVIEW > SYNTHESIZE > FILTER > LOOP > VERIFY.

> **Add your own Standing Order #7+ as needed.** Examples: local-stack default if you use paid APIs, secrets-handling rules, etc.

## Engagement Protocol

### Session Start
1. Read this file + project `MEMORY.md` + `passdown.md` (if working on a project)
2. State orientation: "Last session: [X]. Next up: [Y]. Blocked on: [Z]."
3. Ready to continue — user says "go" or redirects

### During Session
- **ACF loop:** ANCHOR > INTERVIEW > SYNTHESIZE > FILTER > LOOP > VERIFY
- **Provenance tags** on all synthesis: OBSERVED / RECALLED / INFERRED / GENERATED
- **Tier 1 (automatic):** thread tracking, contradiction detection, correction capture
- **Tier 2 (AI initiates):** drift alerts, debrief, passdown writing
- Track threads. Flag drift. Detect contradictions. Resurface parked topics.

### Session End
1. Write/update project `passdown.md` — standing orders for next session
2. Update any topic files that changed during the session
3. Append to `log.md` if you keep one
4. State what was written and where, so the user can verify

## Topic Index

### Layer 1 (this directory — universal, portable)

- [acf-collaboration-loop.md](acf-collaboration-loop.md) — ACF Interview Model v3. Six stages. Provenance Awareness. Three interview types. Named methodologies. The how-we-work document.
- [acf-failed-collaboration-patterns.md](acf-failed-collaboration-patterns.md) — Patterns that have repeatedly broken collaboration. CHECK BEFORE PROPOSING.
- [working-style.md](working-style.md) — How I prefer to work. Session management, communication, testing, planning, memory practices. **Populated through onboarding interview.**

#### Named methodologies (defined in `acf-collaboration-loop.md`)
- **The Six-Stage Loop** — ANCHOR > INTERVIEW > SYNTHESIZE > FILTER > LOOP > VERIFY.
- **Three Interview Types** — Extraction (Stage 2) / Calibration (Stage 3) / Challenge (Stage 6).
- **Provenance Awareness** — Tier 1 self-audit during SYNTHESIZE. Tags claims OBSERVED / RECALLED / INFERRED / GENERATED. Includes the **Calibration Question Toolkit**.
- **Front-Loaded Interview** — batch decisions at session open; lock once; execute. Execution-session variant of Stage 2 (vs. **Interleaved Interview**, the default exploratory form).
- **Reachability Verification** — Stage 6 sub-process. Classifies each shipped item REACHABLE (production caller exists) or SUBSTRATE-ONLY (only test callers).
- **Inventory Status Triage** — periodic LIVE / DEFERRED / SUPERSEDED triage of aging plans-of-record. SUPERSEDED items leave the inventory.
- **The Impact Report** — five-axis proposal evaluation: Confidence / Feasibility / Break-risk / Reversibility / Skeptical-PM. Includes a required **Cost-Shape Declaration** (free / costs us / costs them / costs both).
- **Drift-vs-Capability Distinction** — when the user tightens a rule, distinguish "eliminate capability X" from "eliminate drift into misuse of X" before rewriting.
- **Empirical Verification Discipline** — for safety-critical fixes (cost gates, destructive ops, security boundaries), the pass criterion is observed runtime behavior, not code review.

### Layer 2 (project-specific)

When working on a project, ALSO read that project's MEMORY.md at
`~/.claude/projects/<project-key>/memory/MEMORY.md`. The project's
`CLAUDE.md` at the project root names the key.

> Add a line per active project below as you accumulate them. Example:
> - **{{DEFAULT_PROJECT}}** — `~/.claude/projects/{{DEFAULT_PROJECT_KEY}}/memory/MEMORY.md`
>   Repo: `{{DEFAULT_PROJECT_PATH}}` | Key: `{{DEFAULT_PROJECT_KEY}}`

## The Two-Layer Model

1. **Layer 1** (this dir) — collaboration rules, working style, ACF doctrine. Portable. Loads EVERY session.
2. **Layer 2** (per-project) — architecture, design, active work, strategy. Loads when CWD is in that project.

Layers 1+2 are both just files. They travel with the user, not the project.
