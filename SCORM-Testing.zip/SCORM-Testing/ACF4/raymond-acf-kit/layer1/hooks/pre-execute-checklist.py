#!/usr/bin/env python3
"""Pre-Execute Checklist hook — fires on PreToolUse for Write|Edit|Bash.

Prints the Layer 0 conscience rule + 6-step checklist headers + Standing
Rules trigger lines into context BEFORE every state-modifying tool call.
The full checklist text lives in Luminescent/CLAUDE.md § Pre-Execute
Checklist (auto-loaded); the Layer 0 conscience rule lives in CLAUDE.md
§ Layer 0 — Orienting Question.

This hook is ADVISORY (sys.exit(0)) — it can't mechanically block bad
actions; it puts the checks in fresh context at the moment of execution.
The discipline of actually running the checks is on the assistant.

Fires on:
  - Write — file creation
  - Edit — file modification
  - Bash — any shell command (modifying or read-only)

Read-only Bash filtering is deferred to a future revision.
"""
from __future__ import annotations

import sys

# Force UTF-8 stdout on Windows so unicode triggers don't crash the hook
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        import io

        sys.stdout = io.TextIOWrapper(
            sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True
        )


MESSAGE = """\
*** EXECUTE-PHASE TOOL CALL — PRE-FLIGHT REQUIRED ***
(full checklist in Luminescent/CLAUDE.md § Pre-Execute Checklist;
 conscience rule in § Layer 0 — Orienting Question)

LAYER 0 — CONSCIENCE GATE (apply BEFORE checklist):
  Should this action be taken? Internal answer = action + goal +
  rule (SR/SO if relevant) + alternative + verdict.
  PROCEED -> silent. PUSH BACK -> one line (James's request + clear
  alternative). STOP -> use Alert Protocol below.

CHECKLIST STEPS (run if Layer 0 = PROCEED):
  Step 0 — Is this turn DESIGN or EXECUTE? (this tool call = EXECUTE)
  Step 1 — passdown.md § CURRENT TASK; redirect-aware
  Step 2 — Standing Rules triggers (below); STOP+alert if hit
  Step 3 — failed-approaches.md by SOLUTION SHAPE (not task name)
  Step 4 — Won't break existing system; name what'd fail
  Step 5 — Orienting question (Layer 0): should this action be taken?
  Step 6 — Post-draft Claim Audit before posting

STANDING RULES — TRIGGER LINES (re-read source if any fire):
  1 TIER ROLES — any "Cloud" / "Local" / "Zone" claim; any provider= set
  2 NO MIXINS — any new class in writers_room/ or showrunner-adjacent
  3 READ FAILED-APPROACHES — any "fresh" / "rebuild" / "from scratch" proposal
  4 EDITOR IS PRODUCT — any "pipeline should auto-generate" proposal
  5 TEMPLATES ARE PAGES — any page-assembly / section-per-page thinking
  6 ARCHIVE OBSOLETE — any "how does X work" leading into archive code
  7 SHIPPED-VERIFIED — any "X is done" / "shipped" claim
  8 AUDIT FROM SOURCE — any "surface all X" / "complete coverage" proposal
  9 SRD REFERENCE-ONLY — any picker UI / link-to-SRD-node / "browse SRD" UX
  + MEMORY WRITE LOCATION — any Write/Edit to *.md outside repo tree

ALWAYS-EXECUTE TEXT PATTERNS (treat as EXECUTE even mid-prose):
  "X is [Cloud/Local/Zone N]"      — TIER claim
  "X is wired to Y" / "X feeds Y"  — WIRING claim
  "X is broken" / "X works"        — STATE claim
  "The fix is..." / "We should..." — PRESCRIPTION / RECOMMENDATION
  "Let me [action]..."             — NARRATED ACTION
  "[file] does Y"                  — CODE CLAIM

If any trigger fires AND would violate: STOP. Use AskUserQuestion per
§ Alert Protocol — do NOT proceed with this tool call until alerted.

If you realize mid-response you missed a check, run § Recovery Protocol:
surface the error as ANCHOR CATCH (negative), don't quietly correct.
"""


def main() -> int:
    sys.stdout.write(MESSAGE)
    return 0


if __name__ == "__main__":
    sys.exit(main())
