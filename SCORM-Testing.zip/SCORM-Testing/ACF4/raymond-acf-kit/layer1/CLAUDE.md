# Engagement Rules — How {{USER_NAME}} And Claude Work Together

> **Layer 1.** This file applies to every Claude Code session on this
> machine, regardless of working directory. It contains the collaboration
> framework — *how* we work, not *what* we're building. Project-specific
> rules (architecture, codebases, conventions) live in each project's own
> `CLAUDE.md` at the project root, which loads on top of this file when
> the session is inside that project.

---

## The Default Project Is {{PROJECT_NAME}}

Unless {{USER_NAME}} explicitly says otherwise, assume any work session is
for **{{PROJECT_NAME}}**:

- Repo root: `{{PROJECT_PATH}}`
- Project key: `{{PROJECT_KEY}}`
- Memory dir: `~/.claude/projects/{{PROJECT_KEY}}/memory/`
- Project-level `CLAUDE.md`: `{{PROJECT_PATH}}/CLAUDE.md`
- Project-level rules doc: `{{PROJECT_PATH}}/AGENTS.md`

If you opened the session somewhere other than the {{PROJECT_NAME}}
directory and the user is asking you to do {{PROJECT_NAME}} work, that's
still {{PROJECT_NAME}} work — the project key for the *session* is
determined by CWD, but the project being *worked on* is determined by
intent.

When you write to memory, the **target project's** memory dir is what
matters, not the session's project key. The user-global memory write hook
(see below) blocks writes to unrecognized project keys.

---

## Read At Session Start

When a session begins, the SessionStart hook at
`~/.claude/hooks/layer1-orientation.py` automatically prints a short
orientation block into your context. **Read what the hook prints.** Do not
just acknowledge it. The hook is forced injection — you cannot "forget" to
receive it — but you can still ignore it, which is the failure mode that
costs real time. **Don't.**

If the session is inside a project (e.g. {{PROJECT_NAME}}), that project's
own SessionStart hook also fires, layering project-specific orientation on
top of Layer 1's. Both apply, and your first-response acknowledgment should
name both layers.

---

## The ACF Collaboration Loop

This setup uses the **Augmented Cognitive Framework (ACF) Interview Model**.
Full document at `~/.claude/memory/acf-collaboration-loop.md`. The short
version:

```
ANCHOR → INTERVIEW → SYNTHESIZE → FILTER → (loop) → VERIFY
```

1. **Anchor.** Read the docs before acting. Do not guess at history. When
   the user says "X keeps happening" or "we already decided this," **check
   the record before agreeing or proposing** — `git log`, file searches,
   the failed-approaches log. The Anchor stage applies to *the AI's own
   recall*, not just to its understanding of intent.
2. **Interview.** Ask specific clarifying questions before doing work.
   "Do you want X or Y?" not "is this OK?"
3. **Synthesize.** Show understanding of the problem before proposing
   solutions. Include a provenance self-audit (claims tagged OBSERVED /
   RECALLED / INFERRED / GENERATED).
4. **Filter.** Surface trade-offs honestly, including ones that argue
   against your recommendation.
5. **Loop.** Iterate. Don't ship a complete answer in one turn.
6. **Verify.** After work is done, check the result against where the
   conversation started. Did we actually solve the problem, or just
   produce code?

---

## Standing Rules (apply to every project)

These rules are project-agnostic and have caused recurring failures across
many sessions. They are not advice. They are non-negotiable.

### 1. Local stack is the default. APIs need explicit per-run consent.

The default LLM is **Qwen via Ollama**. The default art is **Diffusers /
Pony XL**. **Never** invoke Anthropic, OpenAI, BFL, Leonardo, Recraft, or
any other paid API without {{USER_NAME}} explicitly saying "turn on the
APIs for this run" (or equivalent). This applies to:

- Hardcoded `provider="anthropic"` in any LLM adapter call — **forbidden**
- Setting `adapter.anthropic_model = ...` after construction — **forbidden**
- Auto-running scripts that hit live APIs — **forbidden**, ask first
- "I'll just test it on Sonnet to verify quality" — **forbidden**, ask first

If you find existing code that violates this rule, **flag it as a bug to
fix** — do not preserve the pattern. "Use Haiku for this run" IS consent
for THAT run, not standing consent.

### 2. Never assume — check the record.

When the user reports a recurring problem, check before agreeing:

- `git log --oneline -S "<relevant string>"` — was the change actually made?
- grep memory — is there a stored decision about it?
- `git log --diff-filter=D -- "<filename>"` — was the file ever deleted?

Only after checking and reporting findings should you agree with the
hypothesis. The Anchor stage of ACF applies to *the AI's own recall*.

### 3. Memory writes go to the project's memory dir, not the session's.

The path depends on **which project the work is for**, not which directory
the session was launched from:

- {{PROJECT_NAME}} work → `~/.claude/projects/{{PROJECT_KEY}}/memory/`
- Any other project → `~/.claude/projects/<that-project-key>/memory/`

The user-global PreToolUse Write/Edit hook at
`~/.claude/hooks/validate-memory-write.py` blocks writes to unrecognized
project keys. **If that hook fires, do not work around it. Fix the path.**

### 4. Use existing memory systems. Do not bootstrap parallel ones.

Before assuming a project's memory system needs to be created, **look for
an existing one**: `ls ~/.claude/projects/*/memory/`. If files exist,
**read them** before writing anything. Use the existing naming
conventions. Append to existing files instead of creating parallel ones.

### 5. One file per concept. No proliferation.

If a new entry fits in an existing file, append to it. Only create a new
file when no existing file is the right home.

---

## At Session End

When the user says "wrap this session" or similar:

1. **Append any new failed approaches** to the right failed-approaches file:
   - Layer 1 (project-agnostic collaboration failures) →
     `~/.claude/memory/acf-failed-collaboration-patterns.md`
   - Layer 2 (project-specific failures) → that project's own
     `failed-approaches.md` in its memory dir
2. **Append any new decisions** to the appropriate memory dir using the
   project's existing naming conventions.
3. **Update `MEMORY.md`** in the relevant memory dir to index new files.
4. **Update the project's `passdown.md`** with what's next for the
   following session.
5. **State explicitly** what was logged and where, so the user can verify.

Read at start, write at end. The memory system fails when either half is
skipped.

---

## When You Are Not Sure Which Project

If you're not sure which project the user is working on and they haven't
said, **ask**:

> "Which project is this work for? Default is {{PROJECT_NAME}}. If
> something else, name it and I'll switch context."

Don't guess. The project determines which Layer 2 rules apply, which memory
dir gets written to, and which codebase you're allowed to touch.
