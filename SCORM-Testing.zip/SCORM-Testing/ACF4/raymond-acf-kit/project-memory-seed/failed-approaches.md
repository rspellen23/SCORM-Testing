# {{PROJECT_NAME}} — Failed Approaches

> Approaches that were tried and explicitly rejected on {{PROJECT_NAME}}.
> **CHECK THIS BEFORE PROPOSING AN APPROACH.** If what you're about to
> suggest is in here, flag it and explain why you're considering it anyway —
> don't propose it as if it's new.
>
> Search by **solution shape**, not by task name: "start fresh" / "rebuild" /
> "from scratch" / "use a mixin" / "hardcode provider" / "bypass the hook" /
> "skip verification" / "defer verification."
>
> This is a FRESH file seeded {{INSTALL_DATE}}. It does not contain James's
> accumulated {{PROJECT_NAME}} failure log — that lives in his separate
> memory tree. Append your own entries as you go.

---

## Format

Each entry:

```
## <Short name of the failed approach> (<date>)

**What was tried:** <one or two sentences>

**Why it failed / was rejected:** <the reason, in {{USER_NAME}}'s terms>

**Do instead:** <the approach that replaced it>
```

---

## Entries

_(none yet — append below as approaches are tried and rejected)_
