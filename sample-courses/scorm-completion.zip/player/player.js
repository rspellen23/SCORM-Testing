/* Nova Course Player runtime.
   - Reveals content gated behind Continue buttons.
   - Handles knowledge-check interactivity (interactive + feedback).
   - Reports to the LMS via SCORM 1.2 (API) or 2004 (API_1484_11):
       durable completion, resume (suspend_data), session time, exit mode.
   Completion fires when every gate is passed, every KC attempted, every required
   media played, and every required card opened — or, for a no-interaction course,
   when the learner reaches the end. Graded courses additionally report a score. */
(function () {
  "use strict";

  /* ---------------- SCORM adapter (1.2 + 2004, durable, with no-LMS fallback) ---------------- */
  var SCORM = (function () {
    var api = null, ver = null, started = 0, finished = false, terminated = false;

    function find(win) {
      var n = 0;
      while (win && n++ < 12) {
        if (win.API_1484_11) { ver = "2004"; return win.API_1484_11; }
        if (win.API)        { ver = "1.2";  return win.API; }
        if (win.parent && win.parent !== win) { win = win.parent; continue; }
        break;
      }
      return null;
    }
    function locate() {
      api = find(window);
      if (!api && window.opener) api = find(window.opener);
      return api;
    }
    var K = {
      status:  function(){ return ver==="2004" ? "cmi.completion_status" : "cmi.core.lesson_status"; },
      success: function(){ return ver==="2004" ? "cmi.success_status"    : "cmi.core.lesson_status"; },
      suspend: function(){ return "cmi.suspend_data"; },        // same key in 1.2 and 2004
      exit:    function(){ return ver==="2004" ? "cmi.exit"     : "cmi.core.exit"; },
      time:    function(){ return ver==="2004" ? "cmi.session_time" : "cmi.core.session_time"; },
      scoreRaw:function(){ return ver==="2004" ? "cmi.score.raw"  : "cmi.core.score.raw"; },
      scoreMin:function(){ return ver==="2004" ? "cmi.score.min"  : "cmi.core.score.min"; },
      scoreMax:function(){ return ver==="2004" ? "cmi.score.max"  : "cmi.core.score.max"; }
    };

    function lastErr(){ try { return ver==="2004" ? api.GetLastError() : api.LMSGetLastError(); } catch(e){ return "?"; } }
    function get(k){ try { return (ver==="2004" ? api.GetValue(k) : api.LMSGetValue(k)) || ""; } catch(e){ return ""; } }
    function set(k, v){
      try {
        var ok = ver==="2004" ? api.SetValue(k, String(v)) : api.LMSSetValue(k, String(v));
        var e = lastErr();
        if (e && e !== "0") console.warn("[nova] SetValue rejected", k, "=", v, "err", e);
        return ok;
      } catch(e){ console.warn("[nova] SetValue threw", k, e); return false; }
    }
    function commit(){ try { ver==="2004" ? api.Commit("") : api.LMSCommit(""); } catch(e){} }

    function fmtTime(ms){
      var s = Math.max(0, Math.round(ms/1000));
      var h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sec = s%60;
      if (ver==="2004") return "PT" + (h?h+"H":"") + (m?m+"M":"") + sec + "S";  // ISO-8601 duration
      function p(n){ return (n<10?"0":"")+n; }                                   // 1.2 CMITimespan HHHH:MM:SS.SS
      return p(h) + ":" + p(m) + ":" + p(sec) + ".00";
    }

    return {
      version: function(){ return ver; },
      isFinished: function(){ return finished; },
      init: function () {
        if (!locate()) { console.info("[nova] no SCORM LMS — running standalone"); return false; }
        started = Date.now();
        try { ver==="2004" ? api.Initialize("") : api.LMSInitialize(""); }
        catch(e){ console.warn("[nova] init error", e); }
        var st = get(K.status()).toLowerCase();
        finished = (st === "completed" || st === "passed");
        if (!finished && st !== "incomplete") set(K.status(), "incomplete"); // never downgrade a finished record
        commit();
        return true;
      },
      loadState: function(){
        if (!api) return null;
        var raw = get(K.suspend());
        if (!raw) return null;
        try { return JSON.parse(raw); } catch(e){ console.warn("[nova] bad suspend_data"); return null; }
      },
      saveState: function(state){
        if (!api) return;
        var s = JSON.stringify(state);
        if (ver !== "2004" && s.length > 4000)                 // 1.2 suspend_data cap ~4096: shed loc, keep progress
          s = JSON.stringify({ g: state.g, k: state.k, m: state.m, o: state.o });
        set(K.suspend(), s);
        commit();
      },
      /* score: optional {raw,min,max,scaled,passed} for graded courses */
      complete: function (score) {
        if (!api) return;
        if (score) {
          set(K.scoreRaw(), score.raw); set(K.scoreMin(), score.min); set(K.scoreMax(), score.max);
          if (ver==="2004") set("cmi.score.scaled", score.scaled);
          if (ver==="2004") { set("cmi.completion_status","completed"); set("cmi.success_status", score.passed ? "passed":"failed"); }
          else              { set("cmi.core.lesson_status", score.passed ? "passed":"failed"); }
        } else {
          if (ver==="2004") { set("cmi.completion_status","completed"); set("cmi.success_status","passed"); }
          else              { set("cmi.core.lesson_status","completed"); }
        }
        finished = true;
        commit();
      },
      /* one cmi.interactions record per KC (graded reporting) */
      interaction: function (n, id, learner, correct) {
        if (!api) return;
        var p = (ver==="2004" ? "cmi.interactions." : "cmi.interactions.") + n + ".";
        set(p+"id", id || ("kc"+n));
        set(p+"type", "choice");
        if (ver==="2004") { set(p+"learner_response", learner); set(p+"result", correct ? "correct":"incorrect"); }
        else              { set(p+"student_response", learner); set(p+"result", correct ? "correct":"wrong"); }
      },
      quit: function () {
        if (!api || terminated) return;
        terminated = true;
        try {
          set(K.time(), fmtTime(Date.now() - started));
          set(K.exit(), finished ? (ver==="2004" ? "normal" : "") : "suspend"); // suspend => resume next launch
          commit();
          ver==="2004" ? api.Terminate("") : api.LMSFinish("");
        } catch(e){ console.warn("[nova] quit error", e); }
      }
    };
  })();

  /* ---------------- Course flow ---------------- */
  function ready(fn){ document.readyState!=="loading" ? fn() : document.addEventListener("DOMContentLoaded", fn); }

  ready(function () {
    SCORM.init();
    var resumed = SCORM.loadState();

    var gates = Array.prototype.slice.call(document.querySelectorAll(".nv-continue"));
    var kcs   = Array.prototype.slice.call(document.querySelectorAll(".nv-kc"));
    var media = Array.prototype.slice.call(document.querySelectorAll("[data-require='1']"));
    var reqOpens = Array.prototype.slice.call(document.querySelectorAll('[data-require-open="1"]'));
    var bar   = document.querySelector(".nv-progress > span");
    var endEl = document.querySelector(".nv-course-end");

    // graded config (Phase D): set on <body data-graded data-pass="80">
    var graded = document.body.getAttribute("data-graded") === "1";
    var passMark = parseInt(document.body.getAttribute("data-pass") || "80", 10);

    var hasInteractive = gates.length + kcs.length + media.length + reqOpens.length > 0;
    var kcSeen = {}, mediaSeen = {}, openSeen = {}, reachedEnd = false, loc = null;
    var completed = SCORM.isFinished();
    var restoring = false;

    function buildState(){
      return {
        g: gates.reduce(function(a,g,i){ if (g.dataset.passed==="1") a.push(i); return a; }, []),
        k: kcSeen, m: Object.keys(mediaSeen), o: Object.keys(openSeen), loc: loc
      };
    }
    function persist(){ if (!restoring) SCORM.saveState(buildState()); }

    function gradedScore(){
      var correct = 0;
      Object.keys(kcSeen).forEach(function(i){ if (kcSeen[i] && kcSeen[i].ok) correct++; });
      var raw = kcs.length ? Math.round(correct / kcs.length * 100) : 0;
      return { raw: raw, min: 0, max: 100, scaled: (raw/100).toFixed(2), passed: raw >= passMark };
    }

    function updateProgress() {
      var totalSteps = gates.length + kcs.length + media.length + reqOpens.length || 1;
      var done = gates.filter(function(g){ return g.dataset.passed === "1"; }).length
               + Object.keys(kcSeen).length + Object.keys(mediaSeen).length + Object.keys(openSeen).length;
      if (bar) bar.style.width = Math.min(100, Math.round(done/totalSteps*100)) + "%";
      persist();
      maybeComplete();
    }

    function maybeComplete() {
      if (completed) return;
      var gatesOk = gates.every(function(g){ return g.dataset.passed === "1"; });
      var kcsOk   = kcs.length === Object.keys(kcSeen).length;
      var mediaOk = media.length === Object.keys(mediaSeen).length;
      var opensOk = reqOpens.length === Object.keys(openSeen).length;
      var floorOk = hasInteractive || reachedEnd;          // no-interaction course must reach the end
      if (gatesOk && kcsOk && mediaOk && opensOk && floorOk) {
        completed = true;
        SCORM.complete(graded ? gradedScore() : null);
        if (graded) {
          var n = 0;
          kcs.forEach(function(kc, i){
            var rec = kcSeen[i]; if (!rec) return;
            SCORM.interaction(n++, kc.getAttribute("data-kc-id") || ("kc"+i), String(rec.opt), rec.ok);
          });
        }
        if (bar) bar.style.width = "100%";
      }
    }

    /* ---- shared interaction handlers (live + restore use the same code) ---- */
    function revealAfter(gate){
      var region = gate.nextElementSibling;
      while (region) {
        if (region.classList && region.classList.contains("nv-gated")) { region.classList.add("revealed"); break; }
        region = region.nextElementSibling;
      }
      return region;
    }
    function passGate(gate, i){
      gate.dataset.passed = "1";
      var btn = gate.querySelector(".nv-btn"); if (btn) btn.disabled = true;
      revealAfter(gate);
      loc = { t: "g", i: i };
    }
    function answerKc(kc, i, optIndex){
      var opts = Array.prototype.slice.call(kc.querySelectorAll(".nv-kc-opt"));
      var fb   = kc.querySelector(".nv-kc-fb");
      var opt  = opts[optIndex]; if (!opt) return;
      var isCorrect = opt.dataset.correct === "1";
      opt.classList.add(isCorrect ? "correct" : "incorrect");
      if (!isCorrect) opts.forEach(function(o){ if (o.dataset.correct==="1") o.classList.add("correct"); });
      opts.forEach(function(o){ o.classList.add("is-disabled"); });
      if (fb) {
        var msg = isCorrect ? fb.getAttribute("data-fb-correct") : fb.getAttribute("data-fb-incorrect");
        fb.innerHTML = msg || "";
        fb.classList.remove("ok","no"); fb.classList.add("show", isCorrect ? "ok":"no");
      }
      kcSeen[i] = { opt: optIndex, ok: isCorrect };
      loc = { t: "kc", i: i };
    }

    /* ---------------- Modals (expanding cards + button=modal CTAs) ---------------- */
    var modals = {}, lastFocus = null;
    Array.prototype.slice.call(document.querySelectorAll(".nv-modal")).forEach(function (m) { modals[m.id] = m; });
    function openModal(id) {
      var m = modals[id]; if (!m) return;
      lastFocus = document.activeElement;
      m.hidden = false; document.body.classList.add("nv-modal-open");
      var c = m.querySelector(".nv-modal-close"); if (c) c.focus();
    }
    function closeModal(m) {
      if (!m || m.hidden) return;
      m.hidden = true;
      if (!document.querySelector(".nv-modal:not([hidden])")) document.body.classList.remove("nv-modal-open");
      var av = m.querySelector("video, audio"); if (av) { try { av.pause(); } catch (e) {} }
      if (lastFocus) { try { lastFocus.focus(); } catch (e) {} }
    }
    Array.prototype.slice.call(document.querySelectorAll("[data-modal]")).forEach(function (t) {
      t.addEventListener("click", function () {
        var id = t.getAttribute("data-modal");
        openModal(id);
        if (t.getAttribute("data-require-open") === "1") { openSeen[id] = true; updateProgress(); }
      });
    });
    Object.keys(modals).forEach(function (id) {
      var m = modals[id];
      m.addEventListener("click", function (e) { if (e.target === m) closeModal(m); });
      var c = m.querySelector(".nv-modal-close"); if (c) c.addEventListener("click", function () { closeModal(m); });
      m.addEventListener("keydown", function (e) {
        if (e.key !== "Tab") return;
        var f = m.querySelectorAll("button, a[href], video, audio, [tabindex]");
        if (!f.length) return;
        var first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      });
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeModal(document.querySelector(".nv-modal:not([hidden])"));
    });

    /* Required media */
    media.forEach(function (el, i) {
      el.addEventListener("ended", function () { mediaSeen["m"+i] = true; updateProgress(); });
    });

    /* Continue gates */
    gates.forEach(function (gate, i) {
      var btn = gate.querySelector(".nv-btn");
      if (!btn) return;
      btn.addEventListener("click", function () {
        var region = (function(){ passGate(gate, i); return revealAfter(gate); })();
        updateProgress();
        (region || gate).scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });

    /* Knowledge checks */
    kcs.forEach(function (kc, i) {
      var opts = Array.prototype.slice.call(kc.querySelectorAll(".nv-kc-opt"));
      opts.forEach(function (opt, oi) {
        opt.addEventListener("click", function () {
          if (kcSeen[i]) return;            // one answer per KC
          answerKc(kc, i, oi);
          updateProgress();
        });
      });
    });

    /* Completion floor: a no-interaction course completes only after the end is seen */
    if (endEl && "IntersectionObserver" in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) { if (e.isIntersecting) { reachedEnd = true; updateProgress(); } });
      });
      io.observe(endEl);
    } else { reachedEnd = true; }   // no IO support: don't trap completion

    /* Exit course */
    var exitBtn = document.querySelector(".nv-exit");
    if (exitBtn) {
      exitBtn.addEventListener("click", function () {
        reachedEnd = true;
        if (!completed) { completed = true; SCORM.complete(graded ? gradedScore() : null); }
        SCORM.quit();
        exitBtn.disabled = true; exitBtn.textContent = "Course complete";
        try { window.top.close(); } catch (e) {}
        window.close();
      });
    }

    /* ---- restore prior progress (resume) ---- */
    if (resumed) {
      restoring = true;
      (resumed.g || []).forEach(function (gi) { if (gates[gi]) passGate(gates[gi], gi); });
      Object.keys(resumed.k || {}).forEach(function (ki) {
        var rec = resumed.k[ki]; if (kcs[ki] && rec) answerKc(kcs[ki], +ki, rec.opt);
      });
      (resumed.m || []).forEach(function (mk) { mediaSeen[mk] = true; });
      (resumed.o || []).forEach(function (ok) { openSeen[ok] = true; });
      loc = resumed.loc || null;
      restoring = false;
      if (loc) {
        var tgt = loc.t === "g" ? gates[loc.i] : (loc.t === "kc" ? kcs[loc.i] : null);
        if (tgt) try { tgt.scrollIntoView({ block: "start" }); } catch (e) {}
      }
    }

    updateProgress();
    window.addEventListener("pagehide", function(){ SCORM.quit(); });
    window.addEventListener("beforeunload", function(){ SCORM.quit(); });
  });
})();
