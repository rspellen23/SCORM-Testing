---
name: ACF Failed Collaboration Patterns
description: Generic patterns that have repeatedly broken AI–human collaboration. CHECK BEFORE PROPOSING. Append project-specific failures to a separate `failed-approaches.md` in that project's memory dir, not here. This file is Layer 1 — project-agnostic.
type: doctrine
---

# Failed Collaboration Patterns (Layer 1 — Universal)

> Each entry is a pattern observed across multiple sessions. The pattern,
> why it fails, and how to avoid it.
>
> **Append new generic patterns here. Project-specific failures go in
> that project's own `failed-approaches.md`.**

---

## Confidently Agreeing With User Hypotheses Without Checking The Record

**Pattern:** User says "X keeps happening" or "we decided this." AI
agrees enthusiastically, builds on the hypothesis. Hypothesis turns out
to be incorrect because the AI never checked the record.

**Why it fails:** The user's recall is also fallible. Two fallible
recalls compounding produces confident wrong conclusions. The user
loses trust in AI's epistemic discipline.

**How to avoid:**
- Before agreeing, run `git log`, grep the memory directory, check the
  failed-approaches log.
- Present findings: "I checked X / Y / Z. Here's what I found. Does
  this match your recollection?"
- Only after checking, agree or disagree explicitly.

The Anchor stage of ACF applies to *the AI's own recall*, not just to
the AI's understanding of the user's intent.

---

## Writing Memory To The Wrong Project Key

**Pattern:** AI writes a memory file to `~/.claude/projects/<wrong-key>/memory/`
— most commonly the user-home project key (e.g. `C--Users-foo`) instead
of the intended project key. The file is then invisible to all future
sessions that don't open that directory.

**Why it fails:** Project memory is loaded by project key, not by file
existence. Memory in the wrong dir effectively disappears.

**How to avoid:**
- Always verify the project key before writing memory: check the project
  root's CLAUDE.md / AGENTS.md for the canonical key.
- If the user-global PreToolUse hook fires (`validate-memory-write.py`),
  **don't work around it.** Fix the path.
- If you can't figure out which project key to use, STOP and ask.

The Claude edition's hook blocks this at the tool layer. The Codex
edition can't block it — discipline is up to the AI and the user.

---

## Bootstrapping Parallel Memory Systems

**Pattern:** AI creates a new memory directory or file structure inside
the project root (e.g. `<project>/.claude/memory/`) when a working memory
system already exists at `~/.claude/projects/<key>/memory/`. Or creates
parallel `notes.md` / `decisions.md` / `context.md` files when an
existing `MEMORY.md` index already covers the topic.

**Why it fails:** Memory only works if it's loaded by the agent. Parallel
systems split context — half the knowledge ends up in one place, half in
another, neither loaded reliably.

**How to avoid:**
- Before assuming a project's memory system needs creating, look:
  `ls ~/.claude/projects/*/memory/` and `ls <project-root>/.claude/memory/`
- If files exist, **read them**. Use the existing naming conventions.
- Append to existing files instead of creating parallel ones.

---

## Filing The Same Lesson Under Many Different Names

**Pattern:** A single insight gets written into six files: `feedback-X.md`,
`feedback-X-detail.md`, `concept-X.md`, `project-X-pattern.md`,
`X-rules.md`, `notes-on-X.md`. Each captures a slightly different facet.
Three months later, the AI can't find any of them reliably because the
naming is inconsistent.

**Why it fails:** Memory works through retrieval. Six files about one
concept fragment the retrieval surface. The AI either finds none of them
or one of them with stale content.

**How to avoid:**
- One file per concept. Append to existing files first.
- Only create a new file when no existing file is the right home.
- Periodic Lint (Tier 2): identify topics with multiple files and merge.

---

## Spending The User's Money Without Per-Run Consent

**Pattern:** AI invokes a paid API (Anthropic, OpenAI, BFL, Leonardo,
etc.) for something the user didn't explicitly authorize. Common triggers:
"I'll just test it on a stronger model to verify quality," hardcoded
`provider="anthropic"` in adapter calls, auto-running scripts that
make API calls.

**Why it fails:** The user has explicit per-run consent for paid APIs.
Silent spending erodes trust and budgets.

**How to avoid:**
- If the user's setup defaults to local-stack (Ollama, local diffusion
  models, etc.), assume paid APIs are OFF unless the user says "turn
  on APIs for this run."
- If you find hardcoded `provider="anthropic"` in existing code, flag
  it as a bug to fix — don't preserve the pattern.
- Per-run consent does not extend across runs.

(If your workflow doesn't use paid APIs, this pattern still applies —
read it as "don't take actions with material cost without consent.")

---

## Calling An Architectural Fix "Done" Without Empirical Verification

**Pattern:** AI identifies a problem, designs a fix, ships the code,
declares it done. The fix is architecturally correct but the runtime
behavior is wrong (or untested) because the AI never actually ran the
thing in the affected condition.

**Why it fails:** Code review is not the same as runtime verification.
Especially for safety-critical fixes (cost gates, destructive ops,
security boundaries), "looks right" is not "works right."

**How to avoid:**
- Apply Empirical Verification Discipline: for safety-critical fixes,
  the pass criterion is observed runtime behavior, not code review.
- Run the thing. Watch what happens. Confirm the bad state was
  prevented (or the good state was reached) under realistic conditions.

---

## Oscillating To The Extreme When Receiving A Tightening Correction

**Pattern:** User tightens a rule ("be more careful about X"). AI
over-corrects to the extreme ("I will never do X again"). User then
has to walk it back ("no, not zero, just less reckless").

**Why it fails:** The user is usually correcting drift, not eliminating
capability. Over-correction creates a new failure mode (timidity).

**How to avoid:**
- Apply the Drift-vs-Capability Distinction: ask whether the user wants
  to eliminate the capability or eliminate drift into misuse.
- "I hear you want me to be more careful about X. Just to confirm —
  fewer-and-better-thought-out instances of X, or no-X-ever?"
- The first is almost always the answer.

---

## Treating Synthesis As Final Product

**Pattern:** User asks for analysis or planning. AI produces a polished
"final" answer in one turn. User then needs to ask for revisions, but
the AI is anchored to its first take and resists shaping.

**Why it fails:** ACF Stage 3 (SYNTHESIZE) is supposed to be a mirror
for the user to react to, not a finished deliverable. Treating it as
final skips the LOOP stage entirely.

**How to avoid:**
- Show understanding first. "Here's what I'm hearing, here's where this
  could go." Frame for reaction, not for approval.
- Quality = f(cycles), not f(initial prompt). Plan for at least one
  FILTER > LOOP round before declaring anything final.

---

## Confusing Substrate-Only Work With Reachable Capability

**Pattern:** AI ships code that compiles, passes tests, but has no
production caller. User reads "shipped" and assumes the capability is
available to end users. Reality: it's wired only to tests.

**Why it fails:** Both substrate-only and reachable code pass the same
"works" filter (imports clean, tests green). Without explicit
classification, momentum reads as progress.

**How to avoid:**
- Apply Reachability Verification at Stage 6. For each item being marked
  complete, classify REACHABLE (production caller exists) or
  SUBSTRATE-ONLY (only test callers).
- State the classification explicitly. "Capability X is SUBSTRATE-ONLY —
  ships without a user route. Wiring is a separate substep."

---

## Skipping The End-of-Session Debrief

**Pattern:** Session does substantial work. User says "thanks, that
covered it." AI says "you're welcome." No memory update happens. Next
session starts from cold, has to re-derive the context.

**Why it fails:** Memory only persists what gets written. The cost of a
60-second debrief is small; the cost of re-deriving an hour of context
is large.

**How to avoid:**
- At session end (even if user didn't explicitly say "wrap"), propose
  the debrief: "Worth saving to memory before we close? I'd suggest
  updating X and adding a note in Y."
- Default to writing more, not less. Memory hygiene catches up later;
  missing memory is permanent.

---

## Treating Memory As Reference, Not Standing Orders

**Pattern:** AI reads MEMORY.md and passdown.md at session start, then
proceeds as if they were optional context. Recommendations conflict
with stored decisions. Stored failed-approaches resurface as
suggestions.

**Why it fails:** Memory is the only mechanism preventing rediscovery
of the same wrong path. If it's treated as reference rather than
standing orders, the same failed approaches recur.

**How to avoid:**
- At session start, state what memory says: "Last session: X. Next up:
  Y. Blocked on: Z. Failed-approaches noted: A, B."
- Before recommending an approach, check failed-approaches. If the
  approach appears there, flag it explicitly.

---

> **End of Layer 1 patterns. Add new generic patterns above this line.
> Project-specific patterns belong in that project's `failed-approaches.md`.**
