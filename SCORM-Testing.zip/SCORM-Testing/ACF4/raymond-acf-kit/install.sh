#!/usr/bin/env bash
#
# ACF two-layer kit installer (macOS / Linux).
#
# Installs:
#   Layer 1 (user-global)  -> ~/CLAUDE.md + ~/.claude/{hooks,memory}/ + hook
#                             registrations merged into ~/.claude/settings.json
#   Layer 2 (Luminescent)  -> <repo>/.claude/{hooks,settings.json} dropped into
#                             your Luminescent clone (the bits that aren't in git)
#   Project memory seed    -> ~/.claude/projects/<key>/memory/ skeletons
#
# Idempotent: re-running won't duplicate hook registrations and won't clobber
# existing project memory. Backs up any file it overwrites (unless --force).
#
set -euo pipefail

# ---------------------------------------------------------------------------
# Defaults / args
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
USER_NAME="${USER:-user}"
PROJECT_NAME="Luminescent"
PROJECT_PATH=""
PROJECT_KEY=""
PLATFORM_ROOT=""
PYTHON=""
DRYRUN=0
FORCE=0

usage() {
  cat <<'USAGE'
ACF two-layer kit installer (macOS / Linux)

Usage:
  ./install.sh --repo <path-to-luminescent-clone> [options]

Required:
  --repo PATH         Absolute path to your local Luminescent clone (Layer 2
                      target). Layer 1 installs regardless; --repo enables Layer 2.

Options:
  --name NAME         Your name (for ~/CLAUDE.md header). Default: $USER
  --project-name NAME Display name of the project. Default: Luminescent
  --key KEY           Project memory key. If omitted, derived from --repo and
                      you'll be told to verify it (see README "Project keys").
  --platform-root P   Path to your Operations clone's platform package, used by
                      the pre-Generate guard. Sets LUMINESCENT_PLATFORM_ROOT hint.
  --python BIN        Python interpreter for hook commands. Default: autodetect
                      (python3, then python).
  --layer1-only       Install Layer 1 only; skip Layer 2 even if --repo given.
  --dry-run           Print what would happen; write nothing.
  --force             Overwrite without creating .acf-backup-<ts> copies.
  -h, --help          This help.

Examples:
  ./install.sh --repo "$HOME/code/Luminescent" --name Raymond
  ./install.sh --repo "$HOME/code/Luminescent" --key "-Users-raymond-code-Luminescent"
  ./install.sh --dry-run --repo "$HOME/code/Luminescent"
USAGE
}

LAYER1_ONLY=0
while [ $# -gt 0 ]; do
  case "$1" in
    --repo) PROJECT_PATH="$2"; shift 2;;
    --name) USER_NAME="$2"; shift 2;;
    --project-name) PROJECT_NAME="$2"; shift 2;;
    --key) PROJECT_KEY="$2"; shift 2;;
    --platform-root) PLATFORM_ROOT="$2"; shift 2;;
    --python) PYTHON="$2"; shift 2;;
    --layer1-only) LAYER1_ONLY=1; shift;;
    --dry-run) DRYRUN=1; shift;;
    --force) FORCE=1; shift;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown argument: $1" >&2; usage; exit 2;;
  esac
done

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
c_info()  { printf '  \033[36m%s\033[0m\n' "$*"; }
c_ok()    { printf '  \033[32m[OK]\033[0m %s\n' "$*"; }
c_warn()  { printf '  \033[33m[WARN]\033[0m %s\n' "$*"; }
c_skip()  { printf '  \033[90m[SKIP]\033[0m %s\n' "$*"; }
c_dry()   { printf '  \033[35m[DRY-RUN]\033[0m %s\n' "$*"; }

# Pick a python interpreter.
if [ -z "$PYTHON" ]; then
  if command -v python3 >/dev/null 2>&1; then PYTHON="python3"
  elif command -v python >/dev/null 2>&1; then PYTHON="python"
  else echo "ERROR: no python3/python on PATH. The hooks are Python; install Python 3.8+." >&2; exit 1
  fi
fi

INSTALL_DATE="$("$PYTHON" -c 'import datetime; print(datetime.date.today().isoformat())')"
TS="$("$PYTHON" -c 'import datetime; print(datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))')"

# Derive a project key from an absolute path, mimicking Claude Code's scheme:
# strip trailing slash, replace path separators and ':' with '-', drop a leading '-'.
derive_key() {
  local p="${1%/}"
  local k="${p//\//-}"
  k="${k//:/-}"
  k="${k#-}"
  printf '%s' "$k"
}

# Substitute placeholders (delegated to python — no sed/slash escaping pain).
export ACF_USER_NAME="$USER_NAME" ACF_PROJECT_NAME="$PROJECT_NAME" \
       ACF_PROJECT_KEY="$PROJECT_KEY" ACF_PROJECT_PATH="$PROJECT_PATH" \
       ACF_PYTHON="$PYTHON" ACF_INSTALL_DATE="$INSTALL_DATE"
subst_to() {
  # $1 = src template, $2 = dest. Honors dry-run + backup.
  local src="$1" dest="$2"
  if [ "$DRYRUN" = "1" ]; then c_dry "would write $dest"; return; fi
  backup "$dest"
  "$PYTHON" - "$src" "$dest" <<'PY'
import os, sys
src, dest = sys.argv[1], sys.argv[2]
repl = {
    "{{USER_NAME}}":    os.environ["ACF_USER_NAME"],
    "{{PROJECT_NAME}}": os.environ["ACF_PROJECT_NAME"],
    "{{PROJECT_KEY}}":  os.environ["ACF_PROJECT_KEY"],
    "{{PROJECT_PATH}}": os.environ["ACF_PROJECT_PATH"],
    "{{PYTHON}}":       os.environ["ACF_PYTHON"],
    "{{INSTALL_DATE}}": os.environ["ACF_INSTALL_DATE"],
}
with open(src, encoding="utf-8") as f:
    text = f.read()
for k, v in repl.items():
    text = text.replace(k, v)
os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
with open(dest, "w", encoding="utf-8") as f:
    f.write(text)
PY
  c_ok "installed $dest"
}

backup() {
  local path="$1"
  [ -e "$path" ] || return 0
  if [ "$FORCE" = "1" ]; then c_warn "overwriting $path (forced)"; return 0; fi
  if [ "$DRYRUN" = "1" ]; then c_dry "would back up $path"; return 0; fi
  cp -R "$path" "$path.acf-backup-$TS"
  c_info "backed up $path -> $path.acf-backup-$TS"
}

ensure_dir() {
  [ -d "$1" ] && return 0
  if [ "$DRYRUN" = "1" ]; then c_dry "would mkdir $1"; else mkdir -p "$1"; c_ok "created $1"; fi
}

# Merge a settings fragment's hooks into a target settings.json (idempotent).
merge_settings() {
  local fragment="$1" target="$2"
  if [ "$DRYRUN" = "1" ]; then c_dry "would merge hooks from $(basename "$fragment") into $target"; return; fi
  backup "$target"
  "$PYTHON" - "$fragment" "$target" <<'PY'
import json, os, sys
fragment, target = sys.argv[1], sys.argv[2]
with open(fragment, encoding="utf-8") as f:
    frag = json.load(f)
frag_hooks = frag.get("hooks", {})
data = {}
if os.path.exists(target):
    try:
        with open(target, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = {}  # caller backed up the broken file already
hooks = data.get("hooks", {})
for evt, groups in frag_hooks.items():
    hooks.setdefault(evt, [])
    existing = {h.get("command")
                for grp in hooks[evt] for h in grp.get("hooks", [])}
    for grp in groups:
        fresh = [h for h in grp.get("hooks", []) if h.get("command") not in existing]
        if not fresh:
            continue
        entry = {}
        if "matcher" in grp:
            entry["matcher"] = grp["matcher"]
        entry["hooks"] = fresh
        hooks[evt].append(entry)
data["hooks"] = hooks
with open(target, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2)
    f.write("\n")
PY
  c_ok "merged hooks into $target"
}

# ---------------------------------------------------------------------------
# Banner + checks
# ---------------------------------------------------------------------------
echo ""
echo "ACF two-layer kit installer"
echo "==========================="
[ "$DRYRUN" = "1" ] && echo "DRY RUN — no changes will be made"
c_info "python: $PYTHON ($("$PYTHON" --version 2>&1))"
c_info "user:   $USER_NAME"
echo ""

USER_HOME="$HOME"

# ---------------------------------------------------------------------------
# Layer 1 (user-global)
# ---------------------------------------------------------------------------
echo "Step 1: Layer 1 (user-global)"
echo "-----------------------------"
ensure_dir "$USER_HOME/.claude/hooks"
ensure_dir "$USER_HOME/.claude/memory"
ensure_dir "$USER_HOME/.claude/projects"

subst_to "$SCRIPT_DIR/layer1/CLAUDE.md"                         "$USER_HOME/CLAUDE.md"
subst_to "$SCRIPT_DIR/layer1/hooks/layer1-orientation.py"       "$USER_HOME/.claude/hooks/layer1-orientation.py"
subst_to "$SCRIPT_DIR/layer1/hooks/pre-execute-checklist.py"    "$USER_HOME/.claude/hooks/pre-execute-checklist.py"
subst_to "$SCRIPT_DIR/layer1/hooks/validate-memory-write.py"    "$USER_HOME/.claude/hooks/validate-memory-write.py"

# Memory docs: don't clobber if the user already has accumulated Layer-1 memory.
for m in MEMORY.md acf-collaboration-loop.md acf-failed-collaboration-patterns.md working-style.md; do
  dest="$USER_HOME/.claude/memory/$m"
  if [ -e "$dest" ] && [ "$FORCE" != "1" ]; then
    c_skip "memory exists, leaving as-is: $dest"
  else
    subst_to "$SCRIPT_DIR/layer1/memory/$m" "$dest"
  fi
done

# Merge Layer-1 hook registrations after substituting {{PYTHON}}.
L1_FRAG_TMP="$(mktemp)"
trap 'rm -f "$L1_FRAG_TMP" "${L2_FRAG_TMP:-}"' EXIT
if [ "$DRYRUN" = "1" ]; then
  c_dry "would merge Layer-1 hooks into $USER_HOME/.claude/settings.json"
else
  "$PYTHON" - "$SCRIPT_DIR/layer1/settings.fragment.json" "$L1_FRAG_TMP" <<'PY'
import os, sys
src, dest = sys.argv[1], sys.argv[2]
with open(src, encoding="utf-8") as f:
    t = f.read().replace("{{PYTHON}}", os.environ["ACF_PYTHON"])
with open(dest, "w", encoding="utf-8") as f:
    f.write(t)
PY
  merge_settings "$L1_FRAG_TMP" "$USER_HOME/.claude/settings.json"
fi

# ---------------------------------------------------------------------------
# Layer 2 (Luminescent) + project memory seed
# ---------------------------------------------------------------------------
echo ""
echo "Step 2: Layer 2 (Luminescent project)"
echo "-------------------------------------"

if [ "$LAYER1_ONLY" = "1" ] || [ -z "$PROJECT_PATH" ]; then
  c_skip "No --repo given (or --layer1-only). Skipping Layer 2 + project memory."
  c_info "Run again with --repo <your-luminescent-clone> to set up Layer 2."
else
  if [ ! -d "$PROJECT_PATH" ]; then
    c_warn "repo path does not exist: $PROJECT_PATH — skipping Layer 2."
  else
    # Sanity: a real Luminescent clone has CLAUDE.md (git-tracked).
    if [ ! -f "$PROJECT_PATH/CLAUDE.md" ]; then
      c_warn "no CLAUDE.md at $PROJECT_PATH — is this really your Luminescent clone?"
      c_warn "Layer-2 rules (CLAUDE.md/AGENTS.md) come from 'git clone'. Clone first, then re-run."
    fi

    # Derive the project key if not given.
    if [ -z "$PROJECT_KEY" ]; then
      PROJECT_KEY="$(derive_key "$PROJECT_PATH")"
      export ACF_PROJECT_KEY="$PROJECT_KEY"
      c_warn "derived project key: $PROJECT_KEY"
      c_warn "VERIFY THIS. After your first Claude session in the repo, run 'ls ~/.claude/projects/'."
      c_warn "If the dir there differs, re-run with --key <actual> (or 'mv' the seeded memory dir)."
    fi

    ensure_dir "$PROJECT_PATH/.claude/hooks"
    subst_to "$SCRIPT_DIR/layer2-luminescent/hooks/session-orientation.py"   "$PROJECT_PATH/.claude/hooks/session-orientation.py"
    subst_to "$SCRIPT_DIR/layer2-luminescent/hooks/validate-memory-write.py" "$PROJECT_PATH/.claude/hooks/validate-memory-write.py"
    subst_to "$SCRIPT_DIR/layer2-luminescent/hooks/check-pregenerate-fast.py" "$PROJECT_PATH/.claude/hooks/check-pregenerate-fast.py"

    # Project settings.json: substitute {{PYTHON}}, then merge (idempotent).
    if [ "$DRYRUN" = "1" ]; then
      c_dry "would merge project hooks into $PROJECT_PATH/.claude/settings.json"
    else
      L2_FRAG_TMP="$(mktemp)"
      "$PYTHON" - "$SCRIPT_DIR/layer2-luminescent/settings.json" "$L2_FRAG_TMP" <<'PY'
import os, sys
src, dest = sys.argv[1], sys.argv[2]
with open(src, encoding="utf-8") as f:
    t = f.read().replace("{{PYTHON}}", os.environ["ACF_PYTHON"])
with open(dest, "w", encoding="utf-8") as f:
    f.write(t)
PY
      merge_settings "$L2_FRAG_TMP" "$PROJECT_PATH/.claude/settings.json"
    fi

    # Verify referenced project hooks resolve.
    if [ -f "$PROJECT_PATH/.claude/hooks/scan-secrets.py" ]; then
      c_ok "scan-secrets.py present (from git clone)"
    else
      c_warn "scan-secrets.py NOT found in clone. It's git-tracked — ensure your clone is complete,"
      c_warn "or remove the scan-secrets lines from $PROJECT_PATH/.claude/settings.json."
    fi

    # Project memory seed — never clobber existing memory.
    PROJ_MEM="$USER_HOME/.claude/projects/$PROJECT_KEY/memory"
    echo ""
    if [ -f "$PROJ_MEM/MEMORY.md" ] && [ "$FORCE" != "1" ]; then
      c_skip "project memory already exists at $PROJ_MEM — leaving it untouched."
    else
      ensure_dir "$PROJ_MEM"
      for s in MEMORY.md passdown.md failed-approaches.md; do
        subst_to "$SCRIPT_DIR/project-memory-seed/$s" "$PROJ_MEM/$s"
      done
      c_info "seeded fresh project memory at $PROJ_MEM"
    fi
  fi
fi

# ---------------------------------------------------------------------------
# Done
# ---------------------------------------------------------------------------
echo ""
echo "Done."
echo ""
echo "Next steps:"
echo "  1. Open a Claude Code session anywhere. The first reply must start with:"
echo "       'Layer 1 orientation loaded. Default project: $PROJECT_NAME (unless told otherwise).'"
echo "  2. Open a session INSIDE your Luminescent clone. The reply should start with:"
echo "       'Layer 1 + Layer 2 (Luminescent) orientation loaded.'"
echo "  3. Verify the memory guard: ask Claude to Write to"
echo "       ~/.claude/projects/c--bogus-key/memory/test.md  -> it must be BLOCKED."
echo "  4. (Optional) export LUMINESCENT_PLATFORM_ROOT=<your Operations clone>/platform/src/luminescent_platform"
echo "     so the pre-Generate guard scans instead of skipping."
echo "  5. Confirm the project key: 'ls ~/.claude/projects/' — if it differs from"
echo "     '$PROJECT_KEY', re-run with --key <actual> (the seed dir can be 'mv'd)."
echo ""
