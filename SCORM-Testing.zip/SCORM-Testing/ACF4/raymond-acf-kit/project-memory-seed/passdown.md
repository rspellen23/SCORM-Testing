# {{PROJECT_NAME}} — Session Passdown

> **READ THIS FIRST at every session open.** It is the authoritative rolling
> handoff. Rewrite the top blocks at session end so the next session starts
> oriented instead of re-deriving context.

---

## CURRENT TASK

_(Nothing yet — this is a fresh memory tree seeded {{INSTALL_DATE}}.)_

State here what you are actively working on. If {{USER_NAME}} redirects
mid-session, STOP, re-anchor on the new direction, and update this block.

## ORIENTATION (last session → next session)

- **Last session:** _(none — first session)_
- **Next up:** Onboarding. On the first real session, confirm with
  {{USER_NAME}} what {{PROJECT_NAME}} work he wants to start with, and skim
  `{{PROJECT_PATH}}/CLAUDE.md` + `AGENTS.md` for the current architecture.
- **Blocked on:** _(nothing)_

## VERIFICATION DEBT

_(none yet)_

## REPO STATE

- Repo: `{{PROJECT_PATH}}` (project key `{{PROJECT_KEY}}`)
- Branch / HEAD: _(fill at session end)_

---

> At session end: update CURRENT TASK, ORIENTATION, VERIFICATION DEBT, and
> REPO STATE. Append any failed approaches to `failed-approaches.md`. Index
> any new topic files in `MEMORY.md`. State what you logged and where.
