# {{PROJECT_NAME}} — Project Memory ({{USER_NAME}})

> Layer 2. Loads when CWD is in the {{PROJECT_NAME}} repo (`{{PROJECT_PATH}}`).
> Stacks on top of Layer 1 (`~/CLAUDE.md` + `~/.claude/memory/`).
>
> **This is a FRESH memory tree.** It was seeded by the ACF kit on
> {{INSTALL_DATE}} with skeletons only — it does NOT contain James's
> accumulated {{PROJECT_NAME}} history. Grow it yourself: read at session
> start, write at session end. The system fails when either half is skipped.

## How this directory works

- **`passdown.md`** — the rolling session handoff. READ IT FIRST every
  session. It says what the last session did, what's next, what's blocked.
  Rewrite it at session end.
- **`failed-approaches.md`** — approaches tried and rejected. CHECK BEFORE
  PROPOSING. Append (don't rewrite) when something fails.
- **`MEMORY.md`** (this file) — the index. One line per topic file. When you
  create a new `feedback-*.md` / `project-*.md`, add a row here.
- **Topic files** — `feedback-<topic>.md` (how the user wants you to work on
  this project) and `project-<topic>.md` (ongoing work / decisions). One
  concept per file. Append to an existing file before creating a new one.

## Project Standing Orders

> These are the {{PROJECT_NAME}} engagement rules. The authoritative copy
> lives in `{{PROJECT_PATH}}/CLAUDE.md` (loaded automatically) — this is the
> short pointer. Read the project CLAUDE.md for the full Standing Rules,
> Layer-0 conscience gate, and Pre-Execute Checklist.

1. Local stack is the default — paid APIs need explicit per-run consent.
2. No mixins. Standalone classes the orchestrator instantiates.
3. Templates ARE pages. No section-per-page assembly.
4. Editor is the product. Pipeline feeds the Editor.
5. SRD content is reference-only — never user-pickable or shipped.

## Topic Index — N=0 active entries

| Topic | File | Hook |
|-------|------|------|
| _(empty — add a row when you create your first topic file)_ | | |
