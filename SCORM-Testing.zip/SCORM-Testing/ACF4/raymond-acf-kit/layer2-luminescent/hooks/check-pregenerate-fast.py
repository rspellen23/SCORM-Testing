#!/usr/bin/env python3
"""Pre-Generate API guard — scans the Operations platform tree for paid-API leakage in iteration code.

Per the Generate-seam architecture rules (project-generate-seam-rearchitecture.md / ADR-0002):
- Pre-Generate code (location_scout, components/zoom_enhance, cast iteration, etc.)
  must use LLMTier.LOCAL only. FAST/QUALITY = Cloud APIs, only legitimate at Generate-time.
- Hardcoded provider="anthropic" / provider="openai" forces a paid path regardless
  of the tier system. Forbidden outside the LLM adapter module.

This hook fires at SessionStart for the Luminescent project. It always exits 0 —
output is informational, not blocking. Allowlists below define the known-OK callers;
any new occurrence outside them surfaces here.

PORTABLE PATH NOTE (ACF kit): the Operations platform tree lives at a
machine-specific path. Set the environment variable LUMINESCENT_PLATFORM_ROOT
to your local Operations clone's platform package, e.g.:
    export LUMINESCENT_PLATFORM_ROOT="$HOME/code/Luminescent.World/platform/src/luminescent_platform"
If unset, the Windows default below is used; if that path doesn't exist the
hook prints a "skipping" line and exits 0 (never blocks).
"""
from __future__ import annotations

import os
import re
import sys
from pathlib import Path

PLATFORM_ROOT = Path(
    os.environ.get(
        "LUMINESCENT_PLATFORM_ROOT",
        "C:/Edusworks/Luminescent.World/platform/src/luminescent_platform",
    )
)

# Files where tier=LLMTier.FAST or LLMTier.QUALITY is legitimate.
# Add to this list ONLY when introducing a new approved Generate-time / utility
# / user-action caller. Iteration-zone code must NEVER appear here.
CLOUD_TIER_ALLOWLIST = {
    # Generate-time creative drafting (HeadWriter)
    "generation/narrative/head_writer/chapters.py",
    "generation/narrative/head_writer/narrative_content.py",
    "generation/narrative/head_writer/quests.py",
    "generation/narrative/head_writer/story_arcs.py",
    # Generate-time creative drafting (BestiaryWriter)
    "generation/cast/bestiary_writer.py",
    # Generate-time packet-based prose drafting (ProseSmith)
    "generation/narrative/prose_smith/__init__.py",
    "generation/narrative/prose_smith/prose_smith.py",
    # Generate-time appendix-hook drafting
    "generation/narrative/appendix_hook_generator/generator.py",
    # Generate-time editorial QA
    "generation/editorial/narrative_qa/llm_analysis.py",
    "generation/editorial/narrative_qa/llm_revision.py",
    # Generate-time post-production
    "orchestration/runtime/post_production.py",
    "orchestration/runtime/batch_services.py",
    # Utility / config / user-action
    "llm/structured_llm.py",
    "llm/adapter.py",
    "reference/lore_forge/ai.py",
    # Plot Weaver post-compile user-action endpoints
    "api/routes/plot_weaver.py",
}

# Files where provider= or *_model = "..." assignments to Cloud providers are OK.
# Outside this set, hardcoded providers bypass the tier system.
PROVIDER_ALLOWLIST = {
    "llm/adapter.py",
}

CLOUD_TIER_RE = re.compile(r"tier\s*=\s*LLMTier\.(FAST|QUALITY)")
PROVIDER_HARDCODE_RE = re.compile(
    r'(?:provider|_provider_override)\s*=\s*["\'](?:anthropic|openai)["\']'
)
MODEL_HARDCODE_RE = re.compile(
    r'(?:anthropic_model|openai_model)\s*=\s*["\']'
)


def scan(pattern: re.Pattern, root: Path, allowlist: set[str]) -> list[tuple[str, int, str]]:
    findings: list[tuple[str, int, str]] = []
    for path in root.rglob("*.py"):
        rel = path.relative_to(root).as_posix()
        if rel in allowlist:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except Exception:
            continue
        for n, line in enumerate(text.splitlines(), 1):
            if pattern.search(line):
                findings.append((rel, n, line.strip()))
    return findings


def main() -> int:
    if not PLATFORM_ROOT.exists():
        print(
            f"[pre-Generate guard] platform tree not found at {PLATFORM_ROOT} — skipping check. "
            f"Set LUMINESCENT_PLATFORM_ROOT to your Operations clone to enable it."
        )
        return 0

    cloud = scan(CLOUD_TIER_RE, PLATFORM_ROOT, CLOUD_TIER_ALLOWLIST)
    providers = scan(PROVIDER_HARDCODE_RE, PLATFORM_ROOT, PROVIDER_ALLOWLIST)
    models = scan(MODEL_HARDCODE_RE, PLATFORM_ROOT, PROVIDER_ALLOWLIST)

    if not cloud and not providers and not models:
        print(
            f"[pre-Generate guard] clean: "
            f"{len(CLOUD_TIER_ALLOWLIST)} approved Cloud-tier callers, "
            f"{len(PROVIDER_ALLOWLIST)} approved provider-config files. "
            f"No iteration-zone Cloud calls or hardcoded providers."
        )
        return 0

    if cloud:
        print(
            f"[pre-Generate guard] WARNING: {len(cloud)} unknown Cloud-tier caller(s) — "
            f"iteration code must use LLMTier.LOCAL only"
        )
        for rel, n, line in cloud:
            print(f"  {rel}:{n}  {line}")
        print(
            "  Rule: pre-Generate code uses Ollama (LOCAL). FAST/QUALITY = Cloud, Generate-time only."
        )
        print(
            "  Fix: change tier to LOCAL, or if intentional add the file to "
            "CLOUD_TIER_ALLOWLIST in check-pregenerate-fast.py"
        )

    if providers:
        print(
            f"[pre-Generate guard] WARNING: {len(providers)} hardcoded provider(s) — "
            f"these bypass the tier system"
        )
        for rel, n, line in providers:
            print(f"  {rel}:{n}  {line}")
        print(
            "  Rule: never hardcode provider= outside adapter.py. Use tier= routing instead."
        )

    if models:
        print(
            f"[pre-Generate guard] WARNING: {len(models)} hardcoded *_model assignment(s) — "
            f"these bypass the tier system"
        )
        for rel, n, line in models:
            print(f"  {rel}:{n}  {line}")
        print(
            "  Rule: model strings live in adapter.py (tier resolver). "
            "Outside callers should never set anthropic_model / openai_model directly."
        )

    return 0


if __name__ == "__main__":
    sys.exit(main())
