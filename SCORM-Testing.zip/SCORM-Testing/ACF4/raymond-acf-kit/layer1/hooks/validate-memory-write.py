#!/usr/bin/env python3
"""Validate Write/Edit calls against the correct memory directory.

PreToolUse hook for Write and Edit tools. If the file_path is under any
`~/.claude/projects/*/memory/` directory, this hook checks that the project
key in the path matches one of the user's known projects.

By default, this hook ALLOWS any project key that's already represented
by an existing memory directory (i.e. you've used that project before),
and BLOCKS writes to project keys that don't have an existing memory dir
(the typical agent error: confusing the user-home project key with a real
project key, then writing memory into a directory that disappears the next
session because no project loads from it).

Customize the ALLOWED_PROJECT_KEYS set below if you want strict allow-listing.

Exit codes:
  0 = allow (path is fine, or not a memory write at all)
  2 = block with stderr message that the agent will see in the tool result
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

# Force UTF-8 on stderr — Windows default cp1252 may mangle messages.
if sys.stderr.encoding and sys.stderr.encoding.lower() != "utf-8":
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        import io

        sys.stderr = io.TextIOWrapper(
            sys.stderr.buffer, encoding="utf-8", errors="replace", line_buffering=True
        )

# ─── CUSTOMIZE THIS ─────────────────────────────────────────────────────
# Option A: Leave ALLOWED_PROJECT_KEYS as None to allow any project key
# whose memory dir already exists on disk (recommended for solo use).
#
# Option B: Set it to a frozenset of explicit project keys to strict-allow
# only those — useful if you want to block memory writes to project keys
# you didn't bless. Example:
#     ALLOWED_PROJECT_KEYS = frozenset({"c--Edusworks-Acme", "c--Users-foo"})
ALLOWED_PROJECT_KEYS: frozenset[str] | None = None
# ────────────────────────────────────────────────────────────────────────

CLAUDE_PROJECTS_ROOT = (Path.home() / ".claude" / "projects").resolve()


def is_memory_path(p: Path) -> bool:
    """True if path is under any project's memory/ directory."""
    try:
        rel = p.resolve().relative_to(CLAUDE_PROJECTS_ROOT)
    except ValueError:
        return False
    parts = rel.parts
    # Expect: <project-key>/memory/...
    return len(parts) >= 2 and parts[1] == "memory"


def project_key_from_path(p: Path) -> str | None:
    """Extract the <project-key> segment from a memory path."""
    try:
        rel = p.resolve().relative_to(CLAUDE_PROJECTS_ROOT)
    except ValueError:
        return None
    parts = rel.parts
    if len(parts) >= 2 and parts[1] == "memory":
        return parts[0]
    return None


def project_key_exists_on_disk(key: str) -> bool:
    """True if ~/.claude/projects/<key>/memory/ already exists."""
    return (CLAUDE_PROJECTS_ROOT / key / "memory").is_dir()


def block(message: str) -> None:
    """Emit a block message to stderr and exit 2."""
    print(message, file=sys.stderr)
    sys.exit(2)


def main() -> int:
    # Read tool input from stdin (Claude Code hook protocol).
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        # Fail open — don't break legitimate writes due to a hook bug.
        return 0

    tool_input = payload.get("tool_input", {}) or {}
    file_path_str = tool_input.get("file_path", "")
    if not file_path_str:
        return 0

    try:
        file_path = Path(file_path_str)
    except (TypeError, ValueError):
        return 0

    # Only act on memory writes — anything else passes straight through.
    if not is_memory_path(file_path):
        return 0

    project_key = project_key_from_path(file_path)
    if project_key is None:
        return 0

    # Allow if explicit allow-list contains the key, OR (if no allow-list)
    # the project's memory dir already exists on disk.
    if ALLOWED_PROJECT_KEYS is not None:
        if project_key in ALLOWED_PROJECT_KEYS:
            return 0
    else:
        if project_key_exists_on_disk(project_key):
            return 0

    # Block writes to project keys that aren't recognized.
    block(
        "BLOCKED: Memory write to an unrecognized project directory.\n"
        "\n"
        f"You tried to write to:\n"
        f"  {file_path}\n"
        f"\n"
        f"That path is under project key '{project_key}', which has no\n"
        f"existing memory directory on disk. This is a documented failure\n"
        f"mode — memory written to a wrong project key never gets loaded\n"
        f"by any future session and effectively disappears.\n"
        f"\n"
        f"To fix:\n"
        f"  - If the target IS a real project: use one of the existing\n"
        f"    project keys at {CLAUDE_PROJECTS_ROOT}.\n"
        f"  - If this is a new project being intentionally set up: the\n"
        f"    user should pre-create the memory dir explicitly OR add the\n"
        f"    key to ALLOWED_PROJECT_KEYS in this hook.\n"
        f"  - If you're confused about which project this is: STOP and ask.\n"
        f"\n"
        f"This block is enforced by the PreToolUse hook at:\n"
        f"  ~/.claude/hooks/validate-memory-write.py\n"
        f"\n"
        f"Do not work around this hook. Fix the path."
    )
    return 0  # unreachable, block() exits


if __name__ == "__main__":
    sys.exit(main())
